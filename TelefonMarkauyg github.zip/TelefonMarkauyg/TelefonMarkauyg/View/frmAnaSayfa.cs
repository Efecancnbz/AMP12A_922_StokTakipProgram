﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelefonMarkauyg.View;

namespace TelefonMarkauyg
{
    public partial class frmAnaSayfa : Form
    {
        public frmAnaSayfa()
        {
            InitializeComponent();
            #region Olaylar Olaylar
            tsmMarka.Click += TsmMarka_Click;
            tsmModel.Click += TsmModel_Click;
            tsmListele.Click += TsmListele_Click;
            #endregion
        }

        private void TsmListele_Click(object? sender, EventArgs e)
        {
            FormGetir(new frmListele());
        }

        private void TsmModel_Click(object? sender, EventArgs e)
        {
            FormGetir(new frmModelEkle());
        }

        private void TsmMarka_Click(object? sender, EventArgs e)
        {
            FormGetir(new frmMarkaAdi());
        }

        private void FormGetir(Form form)
        {
            panel1.Controls.Clear();
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;
            panel1.Controls.Add(form);
            form.Show();
        }
    }
}