﻿namespace TelefonMarkauyg.View
{
    partial class frmMarkaAdi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMarkaAdi));
            pictureBox1 = new PictureBox();
            btnTemizle = new Button();
            btnEkle = new Button();
            txtMarkaAdi = new TextBox();
            lblMarkaAdi = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(76, 30);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(497, 608);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // btnTemizle
            // 
            btnTemizle.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            btnTemizle.Image = (Image)resources.GetObject("btnTemizle.Image");
            btnTemizle.ImageAlign = ContentAlignment.MiddleRight;
            btnTemizle.Location = new Point(857, 357);
            btnTemizle.Name = "btnTemizle";
            btnTemizle.Size = new Size(193, 48);
            btnTemizle.TabIndex = 9;
            btnTemizle.Text = "Temizle";
            btnTemizle.TextAlign = ContentAlignment.MiddleLeft;
            btnTemizle.UseVisualStyleBackColor = true;
            // 
            // btnEkle
            // 
            btnEkle.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            btnEkle.Image = (Image)resources.GetObject("btnEkle.Image");
            btnEkle.ImageAlign = ContentAlignment.MiddleRight;
            btnEkle.Location = new Point(620, 358);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(193, 47);
            btnEkle.TabIndex = 8;
            btnEkle.Text = "Ekle";
            btnEkle.TextAlign = ContentAlignment.MiddleLeft;
            btnEkle.UseVisualStyleBackColor = true;
            // 
            // txtMarkaAdi
            // 
            txtMarkaAdi.Location = new Point(777, 279);
            txtMarkaAdi.Name = "txtMarkaAdi";
            txtMarkaAdi.Size = new Size(231, 23);
            txtMarkaAdi.TabIndex = 7;
            // 
            // lblMarkaAdi
            // 
            lblMarkaAdi.AutoSize = true;
            lblMarkaAdi.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblMarkaAdi.Location = new Point(625, 270);
            lblMarkaAdi.Name = "lblMarkaAdi";
            lblMarkaAdi.Size = new Size(146, 32);
            lblMarkaAdi.TabIndex = 6;
            lblMarkaAdi.Text = "Marka Adı :";
            // 
            // frmMarkaAdi
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1126, 669);
            Controls.Add(pictureBox1);
            Controls.Add(btnTemizle);
            Controls.Add(btnEkle);
            Controls.Add(txtMarkaAdi);
            Controls.Add(lblMarkaAdi);
            Name = "frmMarkaAdi";
            Text = "frmMarkaEkle";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Button btnTemizle;
        private Button btnEkle;
        private TextBox txtMarkaAdi;
        private Label lblMarkaAdi;
    }
}