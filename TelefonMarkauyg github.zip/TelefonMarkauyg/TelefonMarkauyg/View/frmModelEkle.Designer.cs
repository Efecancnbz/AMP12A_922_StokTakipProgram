﻿namespace TelefonMarkauyg
{
    partial class frmModelEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmModelEkle));
            lblMarkaModel = new Label();
            lblModel2 = new Label();
            lblFiyat = new Label();
            lblEkranBoyutu = new Label();
            lblRamMiktari = new Label();
            lblDahiliHafiza = new Label();
            lblPilKapasitesi = new Label();
            textBox1 = new TextBox();
            numericUpDown1 = new NumericUpDown();
            numericUpDown2 = new NumericUpDown();
            numericUpDown3 = new NumericUpDown();
            numericUpDown4 = new NumericUpDown();
            numericUpDown5 = new NumericUpDown();
            comboBox1 = new ComboBox();
            btnTemizleModel = new Button();
            btnEkleModel = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblMarkaModel
            // 
            lblMarkaModel.AutoSize = true;
            lblMarkaModel.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblMarkaModel.Location = new Point(422, 120);
            lblMarkaModel.Name = "lblMarkaModel";
            lblMarkaModel.Size = new Size(100, 32);
            lblMarkaModel.TabIndex = 0;
            lblMarkaModel.Text = "Marka :";
            // 
            // lblModel2
            // 
            lblModel2.AutoSize = true;
            lblModel2.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblModel2.Location = new Point(422, 162);
            lblModel2.Name = "lblModel2";
            lblModel2.Size = new Size(140, 32);
            lblModel2.TabIndex = 1;
            lblModel2.Text = "Model Adı:";
            // 
            // lblFiyat
            // 
            lblFiyat.AutoSize = true;
            lblFiyat.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblFiyat.Location = new Point(422, 209);
            lblFiyat.Name = "lblFiyat";
            lblFiyat.Size = new Size(82, 32);
            lblFiyat.TabIndex = 2;
            lblFiyat.Text = "Fiyat :";
            // 
            // lblEkranBoyutu
            // 
            lblEkranBoyutu.AutoSize = true;
            lblEkranBoyutu.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblEkranBoyutu.Location = new Point(422, 255);
            lblEkranBoyutu.Name = "lblEkranBoyutu";
            lblEkranBoyutu.Size = new Size(181, 32);
            lblEkranBoyutu.TabIndex = 3;
            lblEkranBoyutu.Text = "Ekran Boyutu :";
            // 
            // lblRamMiktari
            // 
            lblRamMiktari.AutoSize = true;
            lblRamMiktari.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblRamMiktari.Location = new Point(422, 298);
            lblRamMiktari.Name = "lblRamMiktari";
            lblRamMiktari.Size = new Size(168, 32);
            lblRamMiktari.TabIndex = 4;
            lblRamMiktari.Text = "Ram Miktarı :";
            // 
            // lblDahiliHafiza
            // 
            lblDahiliHafiza.AutoSize = true;
            lblDahiliHafiza.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblDahiliHafiza.Location = new Point(422, 341);
            lblDahiliHafiza.Name = "lblDahiliHafiza";
            lblDahiliHafiza.Size = new Size(166, 32);
            lblDahiliHafiza.TabIndex = 5;
            lblDahiliHafiza.Text = "Dahili Hafıza:";
            // 
            // lblPilKapasitesi
            // 
            lblPilKapasitesi.AutoSize = true;
            lblPilKapasitesi.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblPilKapasitesi.Location = new Point(422, 386);
            lblPilKapasitesi.Name = "lblPilKapasitesi";
            lblPilKapasitesi.Size = new Size(186, 32);
            lblPilKapasitesi.TabIndex = 6;
            lblPilKapasitesi.Text = "Pil Kapasitesi : ";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(634, 173);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(259, 23);
            textBox1.TabIndex = 7;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(634, 221);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(259, 23);
            numericUpDown1.TabIndex = 8;
            // 
            // numericUpDown2
            // 
            numericUpDown2.Location = new Point(634, 264);
            numericUpDown2.Name = "numericUpDown2";
            numericUpDown2.Size = new Size(259, 23);
            numericUpDown2.TabIndex = 9;
            // 
            // numericUpDown3
            // 
            numericUpDown3.Location = new Point(634, 307);
            numericUpDown3.Name = "numericUpDown3";
            numericUpDown3.Size = new Size(259, 23);
            numericUpDown3.TabIndex = 10;
            // 
            // numericUpDown4
            // 
            numericUpDown4.Location = new Point(634, 353);
            numericUpDown4.Name = "numericUpDown4";
            numericUpDown4.Size = new Size(259, 23);
            numericUpDown4.TabIndex = 11;
            // 
            // numericUpDown5
            // 
            numericUpDown5.Location = new Point(634, 395);
            numericUpDown5.Name = "numericUpDown5";
            numericUpDown5.Size = new Size(259, 23);
            numericUpDown5.TabIndex = 12;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(634, 131);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(259, 23);
            comboBox1.TabIndex = 13;
            // 
            // btnTemizleModel
            // 
            btnTemizleModel.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            btnTemizleModel.Image = (Image)resources.GetObject("btnTemizleModel.Image");
            btnTemizleModel.ImageAlign = ContentAlignment.MiddleRight;
            btnTemizleModel.Location = new Point(634, 456);
            btnTemizleModel.Name = "btnTemizleModel";
            btnTemizleModel.Size = new Size(193, 48);
            btnTemizleModel.TabIndex = 15;
            btnTemizleModel.Text = "Temizle";
            btnTemizleModel.TextAlign = ContentAlignment.MiddleLeft;
            btnTemizleModel.UseVisualStyleBackColor = true;
            // 
            // btnEkleModel
            // 
            btnEkleModel.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            btnEkleModel.Image = (Image)resources.GetObject("btnEkleModel.Image");
            btnEkleModel.ImageAlign = ContentAlignment.MiddleRight;
            btnEkleModel.Location = new Point(422, 456);
            btnEkleModel.Name = "btnEkleModel";
            btnEkleModel.Size = new Size(193, 47);
            btnEkleModel.TabIndex = 14;
            btnEkleModel.Text = "Ekle";
            btnEkleModel.TextAlign = ContentAlignment.MiddleLeft;
            btnEkleModel.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(7, 34);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(409, 493);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 16;
            pictureBox1.TabStop = false;
            // 
            // frmModelEkle
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(905, 578);
            Controls.Add(pictureBox1);
            Controls.Add(btnTemizleModel);
            Controls.Add(btnEkleModel);
            Controls.Add(comboBox1);
            Controls.Add(numericUpDown5);
            Controls.Add(numericUpDown4);
            Controls.Add(numericUpDown3);
            Controls.Add(numericUpDown2);
            Controls.Add(numericUpDown1);
            Controls.Add(textBox1);
            Controls.Add(lblPilKapasitesi);
            Controls.Add(lblDahiliHafiza);
            Controls.Add(lblRamMiktari);
            Controls.Add(lblEkranBoyutu);
            Controls.Add(lblFiyat);
            Controls.Add(lblModel2);
            Controls.Add(lblMarkaModel);
            Name = "frmModelEkle";
            Text = "Sıkçadağıtan İletişim";
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown4).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblMarkaModel;
        private Label lblModel2;
        private Label lblFiyat;
        private Label lblEkranBoyutu;
        private Label lblRamMiktari;
        private Label lblDahiliHafiza;
        private Label lblPilKapasitesi;
        private TextBox textBox1;
        private NumericUpDown numericUpDown1;
        private NumericUpDown numericUpDown2;
        private NumericUpDown numericUpDown3;
        private NumericUpDown numericUpDown4;
        private NumericUpDown numericUpDown5;
        private ComboBox comboBox1;
        private Button btnTemizleModel;
        private Button btnEkleModel;
        private PictureBox pictureBox1;
    }
}