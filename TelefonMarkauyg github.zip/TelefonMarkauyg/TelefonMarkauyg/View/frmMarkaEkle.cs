﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TelefonMarkauyg.View
{
    public partial class frmMarkaAdi : Form
    {
        public frmMarkaAdi()
        {
            InitializeComponent();
            btnEkle.Click += BtnEkle_Click;
            btnTemizle.Click += BtnTemizle_Click;
        }

        private void BtnTemizle_Click(object? sender, EventArgs e)
        {
            txtMarkaAdi.Clear();
            txtMarkaAdi.Focus();
        }

        private void BtnEkle_Click(object? sender, EventArgs e)
        
            {
                string markaAdi = txtMarkaAdi.Text.Trim();

                // Boş kontrolü (! kullanımı ile)
                if (!string.IsNullOrWhiteSpace(markaAdi))
                {
                    // Marka ekleme işlemi (örnek olarak sadece mesaj gösteriyoruz)
                    MessageBox.Show($"'{markaAdi}' markası başarıyla eklendi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Alanı temizle
                    txtMarkaAdi.Clear();
                }
                else
                {
                    MessageBox.Show("Lütfen marka adını giriniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
}
