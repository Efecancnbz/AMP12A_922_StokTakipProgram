﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TelefonMarkauyg
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
            btnGirisYap.Click += new System.EventHandler(btnGirisYap_Click);
            btnTemizle.Click += new System.EventHandler(btnTemizle_Click);


        }
        private void btnGirisYap_Click(object sender, EventArgs e)
        {
            string kullaniciAdi = txtKullaniciAdi.Text.Trim();
            string sifre = txtSifre.Text.Trim();

            // Boş alan kontrolü
            if (string.IsNullOrEmpty(kullaniciAdi) || string.IsNullOrEmpty(sifre))
            {
                MessageBox.Show("Lütfen kullanıcı adı ve şifreyi doldurun!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // İşlemi durdur
            }

            // Kullanıcı doğrulama
            if (kullaniciAdi == "admin" && sifre == "1234")
            {
                MessageBox.Show("Giriş başarılı!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // frmAnaSayfa formunu aç
                frmAnaSayfa anaSayfa = new frmAnaSayfa();
                anaSayfa.Show();

                // Mevcut giriş formunu gizle
                this.Hide();

                // Eğer frmAnaSayfa kapanırsa, giriş ekranını tekrar göster
                anaSayfa.FormClosed += (s, args) => this.Show();
            }
            else
            {
                MessageBox.Show("Kullanıcı adı veya şifre hatalı!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTemizle_Click(object sender, EventArgs e)
        {
            txtKullaniciAdi.Clear();
            txtSifre.Clear();
            txtKullaniciAdi.Focus(); // Kullanıcı adı kutusuna odaklan
        }
    }
}