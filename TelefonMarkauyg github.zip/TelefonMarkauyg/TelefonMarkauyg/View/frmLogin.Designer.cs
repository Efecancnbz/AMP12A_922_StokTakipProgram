﻿namespace TelefonMarkauyg
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLogin));
            lblKullanici = new Label();
            lblSifre = new Label();
            txtKullaniciAdi = new TextBox();
            txtSifre = new TextBox();
            btnGirisYap = new Button();
            btnTemizle = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblKullanici
            // 
            lblKullanici.AutoSize = true;
            lblKullanici.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblKullanici.Location = new Point(205, 213);
            lblKullanici.Name = "lblKullanici";
            lblKullanici.Size = new Size(173, 32);
            lblKullanici.TabIndex = 0;
            lblKullanici.Text = "Kullanıcı Adı :";
            // 
            // lblSifre
            // 
            lblSifre.AutoSize = true;
            lblSifre.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblSifre.Location = new Point(205, 265);
            lblSifre.Name = "lblSifre";
            lblSifre.Size = new Size(80, 32);
            lblSifre.TabIndex = 1;
            lblSifre.Text = "Şifre :";
            // 
            // txtKullaniciAdi
            // 
            txtKullaniciAdi.Location = new Point(384, 224);
            txtKullaniciAdi.Name = "txtKullaniciAdi";
            txtKullaniciAdi.Size = new Size(196, 23);
            txtKullaniciAdi.TabIndex = 2;
            // 
            // txtSifre
            // 
            txtSifre.Location = new Point(384, 276);
            txtSifre.Name = "txtSifre";
            txtSifre.Size = new Size(196, 23);
            txtSifre.TabIndex = 3;
            // 
            // btnGirisYap
            // 
            btnGirisYap.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            btnGirisYap.Image = (Image)resources.GetObject("btnGirisYap.Image");
            btnGirisYap.ImageAlign = ContentAlignment.MiddleRight;
            btnGirisYap.Location = new Point(206, 346);
            btnGirisYap.Name = "btnGirisYap";
            btnGirisYap.Size = new Size(172, 46);
            btnGirisYap.TabIndex = 4;
            btnGirisYap.Text = "Giriş Yap";
            btnGirisYap.TextAlign = ContentAlignment.MiddleLeft;
            btnGirisYap.UseVisualStyleBackColor = true;
            // 
            // btnTemizle
            // 
            btnTemizle.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            btnTemizle.Image = (Image)resources.GetObject("btnTemizle.Image");
            btnTemizle.ImageAlign = ContentAlignment.MiddleRight;
            btnTemizle.Location = new Point(408, 346);
            btnTemizle.Name = "btnTemizle";
            btnTemizle.Size = new Size(172, 46);
            btnTemizle.TabIndex = 5;
            btnTemizle.Text = "Temizle";
            btnTemizle.TextAlign = ContentAlignment.MiddleLeft;
            btnTemizle.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(236, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(284, 191);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // frmLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox1);
            Controls.Add(btnTemizle);
            Controls.Add(btnGirisYap);
            Controls.Add(txtSifre);
            Controls.Add(txtKullaniciAdi);
            Controls.Add(lblSifre);
            Controls.Add(lblKullanici);
            Name = "frmLogin";
            Text = "Sıkçadağıtan İletişim";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblKullanici;
        private Label lblSifre;
        private TextBox txtKullaniciAdi;
        private TextBox txtSifre;
        private Button btnGirisYap;
        private Button btnTemizle;
        private PictureBox pictureBox1;
    }
}