﻿using TelefonMarkauyg.Models;

namespace TelefonMarkauyg
{
    partial class frmAnaSayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            tsmEkle = new ToolStripMenuItem();
            tsmMarka = new ToolStripMenuItem();
            tsmModel = new ToolStripMenuItem();
            tsmListele = new ToolStripMenuItem();
            panel1 = new Panel();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            menuStrip1.Items.AddRange(new ToolStripItem[] { tsmEkle, tsmListele });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1065, 40);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // tsmEkle
            // 
            tsmEkle.DropDownItems.AddRange(new ToolStripItem[] { tsmMarka, tsmModel });
            tsmEkle.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            tsmEkle.Name = "tsmEkle";
            tsmEkle.Size = new Size(72, 36);
            tsmEkle.Text = "Ekle";
            // 
            // tsmMarka
            // 
            tsmMarka.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            tsmMarka.Name = "tsmMarka";
            tsmMarka.Size = new Size(214, 36);
            tsmMarka.Text = "Marka Ekle";

            // 
            // tsmModel
            // 
            tsmModel.Name = "tsmModel";
            tsmModel.Size = new Size(214, 36);
            tsmModel.Text = "Model Ekle";
            // 
            // tsmListele
            // 
            tsmListele.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            tsmListele.Name = "tsmListele";
            tsmListele.Size = new Size(98, 36);
            tsmListele.Text = "Listele";
            // 
            // panel1
            // 
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 40);
            panel1.Name = "panel1";
            panel1.Size = new Size(1065, 650);
            panel1.TabIndex = 1;
            // 
            // frmAnaSayfa
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1065, 690);
            Controls.Add(panel1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "frmAnaSayfa";
            Text = "Sıkçadağıtan İletişim";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem tsmEkle;
        private ToolStripMenuItem tsmMarka;
        private ToolStripMenuItem tsmModel;
        private ToolStripMenuItem tsmListele;
        private Panel panel1;
    }
}