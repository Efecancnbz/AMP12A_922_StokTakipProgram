﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelefonMarkauyg.Models
{
    public class AppDbContext:DbContext
    {
        public virtual DbSet<Marka> Markalar { get; set; }

        public virtual DbSet<TelefonModel> Modeller { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\MSSQLLocalDB;Integrated Security=true;AttachDbFileName=|DataDirectory|Db.mdf;").UseLazyLoadingProxies();

        }

        internal void SaveChanges()
        {
            throw new NotImplementedException();
        }
    }
}
