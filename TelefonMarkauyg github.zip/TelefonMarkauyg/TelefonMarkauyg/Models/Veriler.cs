﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelefonMarkauyg.Models;

namespace TelefonMarkauyg.Models
{
    public static class Veriler
    {
        public static AppDbContext Context = new();

        static Veriler()
        {
            Context.Database.Migrate();

            if (!Context.Markalar.Any())
            {
                OrnekVeri();
            }
        }

        private static void OrnekVeri()
        {
            Context.Markalar.Add(new Marka()
            {
                MarkaAdi = "Samsung",
                Modeller = new List<TelefonModel>
                        {
                            new TelefonModel()
                            {
                                ModelAdi = "Galaxy S10+ Plus",
                                Fiyat = 17699,
                                EkranBoyutu = 6.4,
                                RAMMiktari = 8,
                                DahiliHafıza = 8,
                                PilKapasitesi = 4100,
                            },
                            new TelefonModel()
                            {
                                ModelAdi = "Galaxy S20+ Plus",
                                Fiyat = 19699,
                                EkranBoyutu = 6.4,
                                RAMMiktari = 8,
                                DahiliHafıza = 16,
                                PilKapasitesi = 5100,
                            }
                        }
            });
            Context.SaveChanges();
        }
    }
}
