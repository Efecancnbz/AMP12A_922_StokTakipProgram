﻿namespace TelefonMarkauyg
{
    partial class frmListele
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmListele));
            dataGridView1 = new DataGridView();
            lblAra = new Label();
            textBox1 = new TextBox();
            btnAra = new Button();
            btnListele = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(443, 53);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(495, 408);
            dataGridView1.TabIndex = 0;
            // 
            // lblAra
            // 
            lblAra.AutoSize = true;
            lblAra.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblAra.Location = new Point(443, 9);
            lblAra.Name = "lblAra";
            lblAra.Size = new Size(68, 32);
            lblAra.TabIndex = 1;
            lblAra.Text = "Ara :";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(517, 18);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(351, 23);
            textBox1.TabIndex = 2;
            // 
            // btnAra
            // 
            btnAra.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnAra.Image = (Image)resources.GetObject("btnAra.Image");
            btnAra.ImageAlign = ContentAlignment.MiddleRight;
            btnAra.Location = new Point(874, 17);
            btnAra.Name = "btnAra";
            btnAra.Size = new Size(71, 30);
            btnAra.TabIndex = 3;
            btnAra.Text = "Ara";
            btnAra.TextAlign = ContentAlignment.MiddleLeft;
            btnAra.UseVisualStyleBackColor = true;
            // 
            // btnListele
            // 
            btnListele.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            btnListele.Image = (Image)resources.GetObject("btnListele.Image");
            btnListele.ImageAlign = ContentAlignment.MiddleRight;
            btnListele.Location = new Point(443, 467);
            btnListele.Name = "btnListele";
            btnListele.Size = new Size(495, 44);
            btnListele.TabIndex = 4;
            btnListele.Text = "Listele";
            btnListele.TextAlign = ContentAlignment.MiddleLeft;
            btnListele.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(30, 37);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(381, 424);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // frmListele
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(957, 512);
            Controls.Add(pictureBox1);
            Controls.Add(btnListele);
            Controls.Add(btnAra);
            Controls.Add(textBox1);
            Controls.Add(lblAra);
            Controls.Add(dataGridView1);
            Name = "frmListele";
            Text = "Sıkçadağıtan İletişim";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label lblAra;
        private TextBox textBox1;
        private Button btnAra;
        private Button btnListele;
        private PictureBox pictureBox1;
    }
}