﻿namespace TelefonMarkauyg
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLogin));
            lblKullanici = new Label();
            lblSifre = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            btnGiris = new Button();
            button1 = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblKullanici
            // 
            lblKullanici.AutoSize = true;
            lblKullanici.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblKullanici.Location = new Point(205, 213);
            lblKullanici.Name = "lblKullanici";
            lblKullanici.Size = new Size(173, 32);
            lblKullanici.TabIndex = 0;
            lblKullanici.Text = "Kullanıcı Adı :";
            // 
            // lblSifre
            // 
            lblSifre.AutoSize = true;
            lblSifre.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblSifre.Location = new Point(205, 265);
            lblSifre.Name = "lblSifre";
            lblSifre.Size = new Size(80, 32);
            lblSifre.TabIndex = 1;
            lblSifre.Text = "Şifre :";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(384, 224);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(196, 23);
            textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(384, 276);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(196, 23);
            textBox2.TabIndex = 3;
            // 
            // btnGiris
            // 
            btnGiris.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            btnGiris.Image = (Image)resources.GetObject("btnGiris.Image");
            btnGiris.ImageAlign = ContentAlignment.MiddleRight;
            btnGiris.Location = new Point(206, 346);
            btnGiris.Name = "btnGiris";
            btnGiris.Size = new Size(172, 46);
            btnGiris.TabIndex = 4;
            btnGiris.Text = "Giriş Yap";
            btnGiris.TextAlign = ContentAlignment.MiddleLeft;
            btnGiris.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.ImageAlign = ContentAlignment.MiddleRight;
            button1.Location = new Point(408, 346);
            button1.Name = "button1";
            button1.Size = new Size(172, 46);
            button1.TabIndex = 5;
            button1.Text = "Temizle";
            button1.TextAlign = ContentAlignment.MiddleLeft;
            button1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(236, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(284, 191);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // frmLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox1);
            Controls.Add(button1);
            Controls.Add(btnGiris);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(lblSifre);
            Controls.Add(lblKullanici);
            Name = "frmLogin";
            Text = "Sıkçadağıtan İletişim";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblKullanici;
        private Label lblSifre;
        private TextBox textBox1;
        private TextBox textBox2;
        private Button btnGiris;
        private Button button1;
        private PictureBox pictureBox1;
    }
}