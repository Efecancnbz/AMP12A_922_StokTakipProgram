﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelefonMarkauyg.Models
{
    public class Marka
    {
        public int Id { get; set; }

        public  string MarkaAdi { get; set; }


        public virtual ICollection<TelefonModel> Modeller { get; set; } = new HashSet<TelefonModel>();
    }
}
